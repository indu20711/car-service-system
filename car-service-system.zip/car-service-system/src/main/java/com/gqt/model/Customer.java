package com.gqt.model;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Customer {
	
	private String name;
	private String username;
	private String password;
	private String email;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Customer(String name, String username, String password, String email) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.email = email;
	}
	
	public Customer() {
		super();
	}
	
	public int CustomerRegister() {
		
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system_march", "root", "honey1234");
			
			String s = "insert into customer values(?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(s);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, password);
			pstmt.setString(4, email);
			int rows = pstmt.executeUpdate();
						
			return rows;
						
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int customerLogin() {
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system_march", "root", "honey1234");
			
			String s = "select * from customer where username=?";
			PreparedStatement pstmt = con.prepareStatement(s);
			pstmt.setString(1, username);
			ResultSet res = pstmt.executeQuery();
			System.out.println("model"+password);
			if(res.next()) {
				if(password.equals(res.getString(3))) {
					name = res.getString(1);
					System.out.println("Model"+name);
					return 1;
				}
				else {
					return 0;
				}
			}
			else {
				return -1;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}
	
	public int changePassword() {
		
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system_march", "root", "honey1234");
			
			
			String s="update customer set password=? where username=?";
			PreparedStatement pstmt =con.prepareStatement(s);
			
			pstmt.setString(1, password);
			pstmt.setString(2, username);
			
			int rows = pstmt.executeUpdate();
			
			return rows;
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}
	
	
	public Customer(String name, String username, String email) {
		super();
		this.name = name;
		this.username = username;
		this.email = email;
	}

	public List<Customer> viewCustomer() {

		try {
			
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system_march", "root", "honey1234");
			
			ArrayList<Customer> customerList = new ArrayList();
			String s = "select * from customer";
			PreparedStatement pstmt =con.prepareStatement(s);
			ResultSet res = pstmt.executeQuery();
			
			while(res.next()) {
				name = res.getString(1);
				username = res.getString(2);
				email = res.getString(4);
				
				customerList.add(new Customer(name,username,email));
			}
			return customerList;
			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	

}
